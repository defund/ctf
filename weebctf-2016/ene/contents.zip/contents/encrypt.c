#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    FILE* ene = fopen("ene.png", "rb");
    FILE* and = fopen("a", "wb");
    FILE* or = fopen("o", "wb");
    char K[] = "REDACTED";
    int i = 0;
    char k, c;
    while (i<150196) {
        c = fgetc(ene);
        k = K[i%strlen(K)];
        fputc(k&c, and);
        fputc(k|c, or);
        i++;
    }
    return 0;
}